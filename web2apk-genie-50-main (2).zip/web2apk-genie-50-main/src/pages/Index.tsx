
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, Smartphone, Code, Download, Zap, Shield, Globe } from 'lucide-react';
import AppGenerator from '@/components/AppGenerator';
import FeatureCard from '@/components/FeatureCard';
import HeroSection from '@/components/HeroSection';

const Index = () => {
  const [showGenerator, setShowGenerator] = useState(false);

  const features = [
    {
      icon: Globe,
      title: "Website to APK",
      description: "Transform any website or HTML project into a native Android app instantly."
    },
    {
      icon: Smartphone,
      title: "Native Experience",
      description: "Generate apps with native Android features including splash screens and icons."
    },
    {
      icon: Code,
      title: "No Coding Required",
      description: "Simple interface - just upload your files and configure your app settings."
    },
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Advanced build system generates your APK in minutes, not hours."
    },
    {
      icon: Shield,
      title: "Secure & Reliable",
      description: "Enterprise-grade security with automatic cleanup and data protection."
    },
    {
      icon: Download,
      title: "Instant Download",
      description: "Get your APK file and optional Android Studio project immediately."
    }
  ];

  if (showGenerator) {
    return <AppGenerator onBack={() => setShowGenerator(false)} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-background">
      <HeroSection onGetStarted={() => setShowGenerator(true)} />
      
      {/* Features Section */}
      <section className="py-24 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <Badge variant="secondary" className="mb-4">
              ✨ Features
            </Badge>
            <h2 className="text-4xl font-bold mb-4">
              Everything you need to create
              <span className="bg-gradient-primary bg-clip-text text-transparent"> amazing apps</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Our platform handles the complex Android development process so you can focus on your content.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <FeatureCard
                key={index}
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
                delay={index * 0.1}
              />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-4">
        <div className="container mx-auto max-w-4xl text-center">
          <Card className="bg-gradient-primary text-white border-0 shadow-strong">
            <CardContent className="p-12">
              <h3 className="text-3xl font-bold mb-4">
                Ready to turn your website into an app?
              </h3>
              <p className="text-xl opacity-90 mb-8">
                Join thousands of developers who trust our platform for their app conversion needs.
              </p>
              <Button
                size="lg"
                variant="secondary"
                onClick={() => setShowGenerator(true)}
                className="bg-white text-primary hover:bg-white/90 font-semibold px-8 py-6 text-lg"
              >
                Start Converting Now
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default Index;
