
import { useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Upload, FileArchive, X } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface FileUploadSectionProps {
  uploadedFile: File | null;
  onFileUpload: (file: File | null) => void;
}

const FileUploadSection = ({ uploadedFile, onFileUpload }: FileUploadSectionProps) => {
  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const files = Array.from(e.dataTransfer.files);
    const zipFile = files.find(file => file.name.endsWith('.zip'));
    if (zipFile) {
      onFileUpload(zipFile);
    }
  }, [onFileUpload]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.name.endsWith('.zip')) {
      onFileUpload(file);
    }
  }, [onFileUpload]);

  const formatFileSize = (bytes: number) => {
    const units = ['B', 'KB', 'MB', 'GB'];
    let size = bytes;
    let unitIndex = 0;
    
    while (size >= 1024 && unitIndex < units.length - 1) {
      size /= 1024;
      unitIndex++;
    }
    
    return `${size.toFixed(1)} ${units[unitIndex]}`;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="h-5 w-5" />
          Upload HTML Project
        </CardTitle>
        <CardDescription>
          Upload a ZIP file containing your HTML, CSS, and JavaScript files
        </CardDescription>
      </CardHeader>
      <CardContent>
        {!uploadedFile ? (
          <div
            className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary/50 transition-colors cursor-pointer"
            onDrop={handleDrop}
            onDragOver={(e) => e.preventDefault()}
            onClick={() => document.getElementById('file-input')?.click()}
          >
            <FileArchive className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Drop your ZIP file here</h3>
            <p className="text-muted-foreground mb-4">
              or click to browse your computer
            </p>
            <Button variant="outline">
              Choose File
            </Button>
            <input
              id="file-input"
              type="file"
              accept=".zip"
              onChange={handleFileSelect}
              className="hidden"
            />
            <div className="mt-4 text-xs text-muted-foreground">
              Supports ZIP files up to 50MB
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-primary rounded-lg flex items-center justify-center">
                <FileArchive className="h-5 w-5 text-white" />
              </div>
              <div>
                <div className="font-medium">{uploadedFile.name}</div>
                <div className="text-sm text-muted-foreground">
                  {formatFileSize(uploadedFile.size)}
                  <Badge variant="secondary" className="ml-2">
                    ZIP
                  </Badge>
                </div>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onFileUpload(null)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default FileUploadSection;
