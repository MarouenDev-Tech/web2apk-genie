
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Smartphone, Download, FileArchive, CheckCircle, AlertCircle, Loader, Code } from 'lucide-react';

interface BuildProgressSectionProps {
  status: 'idle' | 'building' | 'completed' | 'error';
  progress: number;
  onBuild: () => void;
  canBuild: boolean;
  appConfig: any;
  websiteUrl: string;
  uploadedFile: File | null;
}

const BuildProgressSection = ({
  status,
  progress,
  onBuild,
  canBuild,
  appConfig,
  websiteUrl,
  uploadedFile
}: BuildProgressSectionProps) => {
  const getStatusIcon = () => {
    switch (status) {
      case 'building':
        return <Loader className="h-5 w-5 animate-spin text-primary" />;
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-success-green" />;
      case 'error':
        return <AlertCircle className="h-5 w-5 text-destructive" />;
      default:
        return <Smartphone className="h-5 w-5" />;
    }
  };

  const getStatusText = () => {
    switch (status) {
      case 'building':
        return 'Building your Android app...';
      case 'completed':
        return 'Your app is ready!';
      case 'error':
        return 'Build failed';
      default:
        return 'Ready to build';
    }
  };

  const getStatusBadge = () => {
    switch (status) {
      case 'building':
        return <Badge variant="secondary">Building</Badge>;
      case 'completed':
        return <Badge className="bg-success-green text-white">Completed</Badge>;
      case 'error':
        return <Badge variant="destructive">Error</Badge>;
      default:
        return <Badge variant="outline">Ready</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Build Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {getStatusIcon()}
            Build Summary
          </CardTitle>
          <CardDescription>
            Review your configuration before building the APK
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-muted/30 rounded-lg">
            <div>
              <div className="text-sm font-medium text-muted-foreground">App Name</div>
              <div className="font-semibold">{appConfig.appName || 'Not set'}</div>
            </div>
            <div>
              <div className="text-sm font-medium text-muted-foreground">Package Name</div>
              <div className="font-semibold">{appConfig.packageName || 'Not set'}</div>
            </div>
            <div>
              <div className="text-sm font-medium text-muted-foreground">Source</div>
              <div className="font-semibold">
                {websiteUrl ? 'Website URL' : uploadedFile ? 'HTML Project' : 'Not set'}
              </div>
            </div>
            <div>
              <div className="text-sm font-medium text-muted-foreground">Status</div>
              <div className="flex items-center gap-2">
                {getStatusBadge()}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Build Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              {getStatusIcon()}
              {getStatusText()}
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {status === 'building' && (
            <div className="space-y-2">
              <Progress value={progress} className="w-full" />
              <div className="text-sm text-muted-foreground">
                {Math.round(progress)}% complete
              </div>
            </div>
          )}

          {status === 'idle' && (
            <Button
              onClick={onBuild}
              disabled={!canBuild}
              size="lg"
              className="w-full bg-gradient-primary text-white"
            >
              <Smartphone className="mr-2 h-5 w-5" />
              Build Android APK
            </Button>
          )}

          {status === 'completed' && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-success-green">
                <CheckCircle className="h-5 w-5" />
                <span className="font-medium">Build completed successfully!</span>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button size="lg" className="bg-gradient-primary text-white">
                  <Download className="mr-2 h-5 w-5" />
                  Download APK
                </Button>
                <Button size="lg" variant="outline">
                  <Code className="mr-2 h-5 w-5" />
                  Download Source Code
                </Button>
              </div>
              
              <div className="p-4 bg-success-green/10 border border-success-green/20 rounded-lg">
                <div className="flex items-center gap-2 text-success-green mb-2">
                  <FileArchive className="h-4 w-4" />
                  <span className="font-medium">Files Ready</span>
                </div>
                <div className="text-sm space-y-1">
                  <div>• {appConfig.appName}.apk (Ready to install)</div>
                  <div>• Android Studio Project (For development)</div>
                </div>
              </div>
            </div>
          )}

          {status === 'error' && (
            <div className="space-y-4">
              <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-lg">
                <div className="flex items-center gap-2 text-destructive mb-2">
                  <AlertCircle className="h-4 w-4" />
                  <span className="font-medium">Build Failed</span>
                </div>
                <div className="text-sm text-muted-foreground">
                  There was an error building your app. Please check your configuration and try again.
                </div>
              </div>
              <Button
                onClick={onBuild}
                variant="outline"
                className="w-full"
              >
                Try Again
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default BuildProgressSection;
