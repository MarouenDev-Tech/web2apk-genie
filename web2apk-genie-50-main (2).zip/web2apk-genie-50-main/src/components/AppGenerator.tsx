
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ArrowLeft, Upload, Globe, Settings, Download, CheckCircle } from 'lucide-react';
import FileUploadSection from '@/components/FileUploadSection';
import AppConfigSection from '@/components/AppConfigSection';
import BuildProgressSection from '@/components/BuildProgressSection';

interface AppGeneratorProps {
  onBack: () => void;
}

const AppGenerator = ({ onBack }: AppGeneratorProps) => {
  const [activeTab, setActiveTab] = useState('input');
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [appConfig, setAppConfig] = useState({
    appName: '',
    packageName: '',
    appIcon: null as File | null,
    splashColor: '#6366F1',
    primaryColor: '#6366F1',
    offlineMode: false,
    pushNotifications: false,
  });
  const [buildStatus, setBuildStatus] = useState<'idle' | 'building' | 'completed' | 'error'>('idle');
  const [buildProgress, setBuildProgress] = useState(0);

  const handleBuild = () => {
    setBuildStatus('building');
    setBuildProgress(0);
    
    // Simulate build process
    const interval = setInterval(() => {
      setBuildProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setBuildStatus('completed');
          return 100;
        }
        return prev + Math.random() * 15;
      });
    }, 500);
  };

  const canBuild = (websiteUrl || uploadedFile) && appConfig.appName && appConfig.packageName;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-background">
      <div className="container mx-auto max-w-4xl py-8 px-4">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="outline"
            size="sm"
            onClick={onBack}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
          <div>
            <h1 className="text-3xl font-bold">APK Generator</h1>
            <p className="text-muted-foreground">Transform your website into an Android app</p>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="input" className="flex items-center gap-2">
              <Upload className="h-4 w-4" />
              Input
            </TabsTrigger>
            <TabsTrigger value="config" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Configure
            </TabsTrigger>
            <TabsTrigger value="build" className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Build
            </TabsTrigger>
          </TabsList>

          <TabsContent value="input" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="h-5 w-5" />
                  Website URL
                </CardTitle>
                <CardDescription>
                  Enter the URL of the website you want to convert to an APK
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Label htmlFor="website-url">Website URL</Label>
                  <Input
                    id="website-url"
                    placeholder="https://example.com"
                    value={websiteUrl}
                    onChange={(e) => setWebsiteUrl(e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>

            <div className="flex items-center gap-4">
              <hr className="flex-1" />
              <span className="text-muted-foreground">OR</span>
              <hr className="flex-1" />
            </div>

            <FileUploadSection
              uploadedFile={uploadedFile}
              onFileUpload={setUploadedFile}
            />

            <div className="flex justify-end">
              <Button
                onClick={() => setActiveTab('config')}
                disabled={!websiteUrl && !uploadedFile}
                className="bg-gradient-primary text-white"
              >
                Next: Configure App
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="config" className="space-y-6">
            <AppConfigSection
              config={appConfig}
              onConfigChange={setAppConfig}
            />

            <div className="flex justify-between">
              <Button
                variant="outline"
                onClick={() => setActiveTab('input')}
              >
                Back
              </Button>
              <Button
                onClick={() => setActiveTab('build')}
                disabled={!appConfig.appName || !appConfig.packageName}
                className="bg-gradient-primary text-white"
              >
                Next: Build APK
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="build" className="space-y-6">
            <BuildProgressSection
              status={buildStatus}
              progress={buildProgress}
              onBuild={handleBuild}
              canBuild={canBuild}
              appConfig={appConfig}
              websiteUrl={websiteUrl}
              uploadedFile={uploadedFile}
            />

            <div className="flex justify-start">
              <Button
                variant="outline"
                onClick={() => setActiveTab('config')}
                disabled={buildStatus === 'building'}
              >
                Back
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AppGenerator;
