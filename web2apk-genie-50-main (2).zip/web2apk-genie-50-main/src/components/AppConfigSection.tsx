
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Smartphone, Palette, Upload, Image, Bell, Wifi } from 'lucide-react';

interface AppConfig {
  appName: string;
  packageName: string;
  appIcon: File | null;
  splashColor: string;
  primaryColor: string;
  offlineMode: boolean;
  pushNotifications: boolean;
}

interface AppConfigSectionProps {
  config: AppConfig;
  onConfigChange: (config: AppConfig) => void;
}

const AppConfigSection = ({ config, onConfigChange }: AppConfigSectionProps) => {
  const updateConfig = (key: keyof AppConfig, value: any) => {
    onConfigChange({ ...config, [key]: value });
  };

  const handleIconUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      updateConfig('appIcon', file);
    }
  };

  return (
    <div className="space-y-6">
      {/* Basic Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Smartphone className="h-5 w-5" />
            Basic Information
          </CardTitle>
          <CardDescription>
            Configure your app's basic details and metadata
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="app-name">App Name *</Label>
              <Input
                id="app-name"
                placeholder="My Awesome App"
                value={config.appName}
                onChange={(e) => updateConfig('appName', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="package-name">Package Name *</Label>
              <Input
                id="package-name"
                placeholder="com.example.myapp"
                value={config.packageName}
                onChange={(e) => updateConfig('packageName', e.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Visual Customization */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Palette className="h-5 w-5" />
            Visual Customization
          </CardTitle>
          <CardDescription>
            Customize your app's appearance and branding
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* App Icon */}
          <div className="space-y-2">
            <Label>App Icon</Label>
            <div className="flex items-center gap-4">
              {config.appIcon ? (
                <div className="w-16 h-16 rounded-lg overflow-hidden border">
                  <img
                    src={URL.createObjectURL(config.appIcon)}
                    alt="App icon preview"
                    className="w-full h-full object-cover"
                  />
                </div>
              ) : (
                <div className="w-16 h-16 rounded-lg border-2 border-dashed border-border flex items-center justify-center">
                  <Image className="h-6 w-6 text-muted-foreground" />
                </div>
              )}
              <Button
                variant="outline"
                onClick={() => document.getElementById('icon-input')?.click()}
              >
                <Upload className="h-4 w-4 mr-2" />
                {config.appIcon ? 'Change Icon' : 'Upload Icon'}
              </Button>
              <input
                id="icon-input"
                type="file"
                accept="image/*"
                onChange={handleIconUpload}
                className="hidden"
              />
            </div>
            <p className="text-sm text-muted-foreground">
              Recommended: 512x512 pixels, PNG format
            </p>
          </div>

          {/* Colors */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="primary-color">Primary Color</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="primary-color"
                  type="color"
                  value={config.primaryColor}
                  onChange={(e) => updateConfig('primaryColor', e.target.value)}
                  className="w-12 h-10 p-1 rounded cursor-pointer"
                />
                <Input
                  type="text"
                  value={config.primaryColor}
                  onChange={(e) => updateConfig('primaryColor', e.target.value)}
                  className="flex-1"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="splash-color">Splash Screen Color</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="splash-color"
                  type="color"
                  value={config.splashColor}
                  onChange={(e) => updateConfig('splashColor', e.target.value)}
                  className="w-12 h-10 p-1 rounded cursor-pointer"
                />
                <Input
                  type="text"
                  value={config.splashColor}
                  onChange={(e) => updateConfig('splashColor', e.target.value)}
                  className="flex-1"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Features */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            App Features
          </CardTitle>
          <CardDescription>
            Enable additional features for your mobile app
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <Wifi className="h-4 w-4" />
                <Label>Offline Mode</Label>
              </div>
              <p className="text-sm text-muted-foreground">
                Allow your app to work without an internet connection
              </p>
            </div>
            <Switch
              checked={config.offlineMode}
              onCheckedChange={(checked) => updateConfig('offlineMode', checked)}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <Bell className="h-4 w-4" />
                <Label>Push Notifications</Label>
              </div>
              <p className="text-sm text-muted-foreground">
                Enable Firebase push notifications (requires Firebase setup)
              </p>
            </div>
            <Switch
              checked={config.pushNotifications}
              onCheckedChange={(checked) => updateConfig('pushNotifications', checked)}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AppConfigSection;
