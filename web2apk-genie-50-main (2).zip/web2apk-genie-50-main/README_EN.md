# web2apk-genie-50-main

Copyright © 2025 Marouene Ayadi. All rights reserved.
Do not modify or remove this notice from any project files.

## Project Description
A tool to easily and quickly convert websites into Android applications.

## Usage
- Install the requirements.
- Run the app and follow the instructions.

## Main Folders
- `src/` : Contains the main source code.
- `public/` : Public files such as images and robots files.

## Contact
For any inquiries or support, please contact Marouene Ayadi.
